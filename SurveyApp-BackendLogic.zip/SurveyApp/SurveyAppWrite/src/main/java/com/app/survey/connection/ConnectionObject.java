package com.app.survey.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionObject {

	public static Connection getConnection() {
		
		String URL = "jdbc:oracle:thin:@localhost:1521:XE";
		Properties info = new Properties();
		info.put("user", "manish");
		info.put("password", "manish");
		
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(URL,info);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
