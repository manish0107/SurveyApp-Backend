package com.app.survey.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.model.QuesAns;
import com.app.survey.service.AddQAnsService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.impl","com.app.survey.service"})
public class AddQAnsController {

	@Autowired
	private AddQAnsService addQAnsService;
	
	@RequestMapping(value = "/addQA", method = RequestMethod.POST)
	public int addQuestionAnswer(@RequestBody QuesAns quesAns) {
		return addQAnsService.addQuestionAnswer(quesAns);
	}
}
