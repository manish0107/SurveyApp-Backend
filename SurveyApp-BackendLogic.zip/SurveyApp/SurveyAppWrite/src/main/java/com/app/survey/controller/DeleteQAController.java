package com.app.survey.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.service.DeleteQAnsService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.impl"})
public class DeleteQAController {

	@Autowired
	private DeleteQAnsService deleteQAnsService;
	
	@RequestMapping(value = "/deleteQA/{question}", method = RequestMethod.DELETE)
	public int deleteQA(@PathVariable("question") String question) {
		
		return deleteQAnsService.deleteQuestionAnswer(question.trim());
	}
}
