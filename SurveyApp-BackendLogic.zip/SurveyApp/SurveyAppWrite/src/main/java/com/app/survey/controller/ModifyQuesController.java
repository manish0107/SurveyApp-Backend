package com.app.survey.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.model.QuesAns;
import com.app.survey.service.ModifyQAnsService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.impl"})
public class ModifyQuesController {

	@Autowired
	private ModifyQAnsService modifyQAnsService;
	
	@RequestMapping(value = "/modifyQuestion", method = RequestMethod.POST)
	public int modifyQuestion(@RequestBody QuesAns quesAns) {
		return modifyQAnsService.modifyQuestionAnswer(quesAns);
	}
	
}
