package com.app.survey.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.model.Survey;
import com.app.survey.service.OnSubmitOfSurveyService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.impl"})
public class OnSubmitOfSurveyController {

	@Autowired
	private OnSubmitOfSurveyService onSubmitOfSurveyService;
	
	@RequestMapping(value = "/submitSurvey", method = RequestMethod.POST)
	public String submitSurvey(@RequestBody List<Survey> survey) {
		return onSubmitOfSurveyService.submitSurvey(survey);
	}
}
