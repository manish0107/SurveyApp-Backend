package com.app.survey.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.app.survey.connection.ConnectionObject;
import com.app.survey.model.QuesAns;
import com.app.survey.service.AddQAnsService;

@Service
public class AddQAnsServiceImpl implements AddQAnsService {

	public int addQuestionAnswer(QuesAns quesAns) {
		int updated = 0;
		Connection conn = null;
		try {
		conn = ConnectionObject.getConnection();
		Statement stmt = null;
		stmt = conn.createStatement();
		
		Map<String, Integer> answerWithInd = quesAns.getAnsCInd();
		for(Map.Entry<String, Integer> entry : answerWithInd.entrySet()) {
			String sql = "INSERT INTO T_SURVEY_QA "+"VALUES ('"+quesAns.getQuestion()+"','"+entry.getKey()+"',"+entry.getValue()+")";
			updated = stmt.executeUpdate(sql);
			updated++;
		}
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return updated;
	}

}
