package com.app.survey.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.stereotype.Service;

import com.app.survey.connection.ConnectionObject;
import com.app.survey.service.DeleteQAnsService;

@Service
public class DeleteQAnsServiceImpl implements DeleteQAnsService {

	public int deleteQuestionAnswer(String question) {
		int deleted = 0;
		Connection conn = null;
		try {
			conn = ConnectionObject.getConnection();
			Statement stmt = null;
			stmt = conn.createStatement();

			String sql = "DELETE FROM T_SURVEY_QA WHERE QUESTION='" + question + "'";
			deleted = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return deleted;

	}

}
