package com.app.survey.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.app.survey.connection.ConnectionObject;
import com.app.survey.model.QuesAns;
import com.app.survey.service.ModifyQAnsService;

@Service
public class ModifyQAnsServiceImpl implements ModifyQAnsService {

	public int modifyQuestionAnswer(QuesAns quesAns) {
	
		int updated = 0;
		Connection conn = null;
		try {
			conn = ConnectionObject.getConnection();
			Statement stmt = null;
			stmt = conn.createStatement();

			String sqlQA = "select question,answer,correctind from t_survey_qa where question='"+quesAns.getQuestion()+"'";
			ResultSet rs = stmt.executeQuery(sqlQA);
			while(rs.next()) {
				String ans = rs.getString("answer");
				for(Map.Entry<String, Integer> entry : quesAns.getAnsCInd().entrySet()) {
					if(ans.equals(entry.getKey())) {
						String updateQA = "update t_survey_qa set answer='"+entry.getKey()+"', correctind="+entry.getValue()+" where question='"+quesAns.getQuestion()+"'";
						updated = stmt.executeUpdate(updateQA);
					}
					else {
						String sqlAdd = "insert into t_survey_qa "+"values ('"+quesAns.getQuestion()+"','"+entry.getKey()+"',"+entry.getValue()+")";
						updated = stmt.executeUpdate(sqlAdd);
					}
				}
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return updated;
	}

}
