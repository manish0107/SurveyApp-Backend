package com.app.survey.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import org.springframework.stereotype.Service;

import com.app.survey.connection.ConnectionObject;
import com.app.survey.model.Survey;
import com.app.survey.service.OnSubmitOfSurveyService;

@Service
public class OnSubmitOfSurveyServiceImpl implements OnSubmitOfSurveyService {

	private String SUCCESS = "Survey submitted successfully";
	public String submitSurvey(List<Survey> surveyList) {
		int updated = 0;
		Connection conn = null;
		Statement stmt = null;
		try {
			conn = ConnectionObject.getConnection();
			stmt = conn.createStatement();
			for(Survey survey : surveyList) {
				String question = survey.getQuestion();
				int surveyNbr = survey.getSurveyNbr();
				
				for(String answers : survey.getAnswers()) {
					String ans = answers.toString();
					String sql = "insert into t_survey_r" + " values ('"+question+"','"+ans+"',"+surveyNbr+")";
					updated = stmt.executeUpdate(sql);
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		System.out.println("updated: "+updated);
		return SUCCESS;

	
	}

}
