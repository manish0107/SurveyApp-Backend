package com.app.survey.model;

import java.util.Map;

public class QuesAns {

	private String question;
	private Map<String, Integer> ansCInd;
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public Map<String, Integer> getAnsCInd() {
		return ansCInd;
	}
	public void setAnsCInd(Map<String, Integer> ansCInd) {
		this.ansCInd = ansCInd;
	}
	
}
