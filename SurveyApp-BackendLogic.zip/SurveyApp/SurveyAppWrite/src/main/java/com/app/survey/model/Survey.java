package com.app.survey.model;

import java.util.List;

public class Survey {

	private String question;
	private int surveyNbr;
	private List<String> answers;
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getSurveyNbr() {
		return surveyNbr;
	}
	public void setSurveyNbr(int surveyNbr) {
		this.surveyNbr = surveyNbr;
	}
	public List<String> getAnswers() {
		return answers;
	}
	public void setAnswers(List<String> answers) {
		this.answers = answers;
	}
	
}
