package com.app.survey.service;

import org.springframework.stereotype.Component;

import com.app.survey.model.QuesAns;

@Component
public interface AddQAnsService {

	int addQuestionAnswer(QuesAns quesAns);
}
