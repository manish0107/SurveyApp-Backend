package com.app.survey.service;

import org.springframework.stereotype.Component;

@Component
public interface DeleteQAnsService {

	int deleteQuestionAnswer(String question);
}
