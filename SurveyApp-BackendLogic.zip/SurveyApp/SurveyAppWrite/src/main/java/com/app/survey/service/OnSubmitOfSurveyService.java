package com.app.survey.service;

import java.util.List;

import com.app.survey.model.Survey;

public interface OnSubmitOfSurveyService {

	String submitSurvey(List<Survey> survey);
}
