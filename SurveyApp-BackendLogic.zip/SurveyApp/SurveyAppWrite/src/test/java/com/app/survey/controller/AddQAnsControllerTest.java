package com.app.survey.controller;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.app.survey.model.QuesAns;
import com.app.survey.service.AddQAnsService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AddQAnsController.class, secure = false)
public class AddQAnsControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AddQAnsService addQAnsService;
	
	String exampleQuesAns = "{\"question\":\"what is your address\",\"ansCInd\":{\"Bangalore\":1}}";
	
	@Test
	public void testAddQAns() throws Exception {
		
		QuesAns quesAns = new QuesAns();
		quesAns.setQuestion("what is yor address");
		Map<String, Integer> ansCInd = new HashMap<String, Integer>();
		ansCInd.put("Bangalore", 1);
		quesAns.setAnsCInd(ansCInd);
		Mockito.when(addQAnsService.addQuestionAnswer(Mockito.any(QuesAns.class))).thenReturn(1);

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/addQA")
				.accept(MediaType.APPLICATION_JSON).content(exampleQuesAns)
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.OK.value(), response.getStatus());

	}
}
