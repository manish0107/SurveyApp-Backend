package com.app.survey.controller;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.app.survey.model.QuesAns;
import com.app.survey.service.ModifyQAnsService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ModifyQuesController.class, secure = false)
public class ModifyQuesControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ModifyQAnsService modifyQAnsService;
	String exampleQuesAns = "{\"question\":\"what is your address\",\"ansCInd\":{\"Bangalore\":1}}";

	@Test
	public void testModifyQuestion() throws Exception {

		QuesAns quesAns = new QuesAns();
		quesAns.setQuestion("what is yor address");
		Map<String, Integer> ansCInd = new HashMap<String, Integer>();
		ansCInd.put("Bangalore", 1);
		quesAns.setAnsCInd(ansCInd);
		Mockito.when(modifyQAnsService.modifyQuestionAnswer(Mockito.any(QuesAns.class))).thenReturn(1);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/modifyQuestion")
				.accept(MediaType.APPLICATION_JSON).content(exampleQuesAns).contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();

		assertEquals(HttpStatus.OK.value(), response.getStatus());

	}

}
