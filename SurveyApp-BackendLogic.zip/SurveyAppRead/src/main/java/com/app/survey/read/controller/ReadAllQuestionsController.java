package com.app.survey.read.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.read.service.ReadAllQuestionsService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.read.impl"})
public class ReadAllQuestionsController {

	@Autowired
	private ReadAllQuestionsService readAllQuestionsService;
	
	@RequestMapping(value = "/getAllQuestions", method = RequestMethod.GET)
	public List<String> getAllQuestions(){
		return readAllQuestionsService.getAllQuestions();
	}
}
