package com.app.survey.read.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.read.model.SurveyResPercent;
import com.app.survey.read.service.ReadQResPercentageService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.read.impl"})
public class ReadQResPercentageController {

	@Autowired
	private ReadQResPercentageService readQResPercentageService;
	
	@RequestMapping(value = "/responsePercentQues/{question}", method = RequestMethod.GET)
	public SurveyResPercent getResponsePrctQues(@PathVariable("question") String question){
		return readQResPercentageService.getResponsePrctQues(question);
	}
}
