package com.app.survey.read.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.app.survey.read.model.Question;
import com.app.survey.read.service.ReadQuestionWithAllAnsService;

@RestController
@ComponentScan(basePackages = {"com.app.survey.read.impl"})
public class ReadQuestionWithAllAnsController {

	@Autowired
	private ReadQuestionWithAllAnsService readQuestionWithAllAnsService;
	
	@RequestMapping(value = "/getQuestionByName/{question}", method = RequestMethod.GET)
	public Question getQuestionWithAnswers(@PathVariable("question") String question){
		return readQuestionWithAllAnsService.getQuestionWithAnswers(question);
	}
}
