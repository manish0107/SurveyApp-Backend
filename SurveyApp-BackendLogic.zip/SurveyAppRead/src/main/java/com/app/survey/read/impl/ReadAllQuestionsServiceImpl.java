package com.app.survey.read.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

import com.app.survey.read.connection.ConnectionObject;
import com.app.survey.read.service.ReadAllQuestionsService;
@Service
public class ReadAllQuestionsServiceImpl implements ReadAllQuestionsService {

	public List<String> getAllQuestions() {
		
		Connection conn = null;
		List<String> listQuestion = null;
		try {
		conn = ConnectionObject.getConnection();
		listQuestion = new ArrayList<String>();
		Statement stmt = null;
		stmt = conn.createStatement();
		String sql = "select distinct question from t_survey_qa";
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()) {
			String question = rs.getString("question");
			listQuestion.add(question);
		}
		
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return listQuestion;
	
	}

}
