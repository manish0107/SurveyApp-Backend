package com.app.survey.read.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.app.survey.read.connection.ConnectionObject;
import com.app.survey.read.model.SurveyResPercent;
import com.app.survey.read.service.ReadQResPercentageService;

@Service
public class ReadQResPercentageServiceImpl implements ReadQResPercentageService {

	public SurveyResPercent getResponsePrctQues(String question) {
		
		Connection conn = null;
		Map<String, Integer> map = null;
		SurveyResPercent responsePercent = null;
		Map<String, Integer> percentBreakup = null;
		int surveyNbr = 0;
		int totalAnswersSelected = 0;		
		try {
			map = new HashMap<String, Integer>();
			conn = ConnectionObject.getConnection();
			responsePercent = new SurveyResPercent();
			Statement stmt = null;
			percentBreakup = new HashMap<String, Integer>();
			stmt = conn.createStatement();
			
			String sqlSurveyNbr = "select max(surveynbr) from t_survey_r";
			ResultSet rs = stmt.executeQuery(sqlSurveyNbr);
			if(rs.next()) {
				surveyNbr = rs.getInt(1);
			}
			String totalAnsOption = "select answer from t_survey_qa where question='"+question+"' minus select checkedanswer from t_survey_r where question='"+question+"'";
			ResultSet rs1 = stmt.executeQuery(totalAnsOption);
			while(rs1.next()) {
				String ans = rs1.getString("answer");
				map.put(ans, 0);
			}
		    responsePercent.setTotalSurveyDone(surveyNbr);
		    String sqlAllAnsWithAttemptNbr = "select checkedanswer, count(checkedanswer) as ansCount from t_survey_r where question='"+question+"' "+"group by checkedanswer";
		    ResultSet rs2 = stmt.executeQuery(sqlAllAnsWithAttemptNbr);
		    while(rs2.next()) {
		    	String answer = rs2.getString("checkedanswer");
		    	int ansCount = rs2.getInt("ansCount");
		    	totalAnswersSelected = totalAnswersSelected+ansCount;
		    	map.put(answer, ansCount);
		    }
		    for(Map.Entry<String, Integer> entry : map.entrySet()) {
		    	String ans = entry.getKey();
		    	Integer percentAttempt = (entry.getValue() *100)/totalAnswersSelected;
		    	percentBreakup.put(ans, percentAttempt);
		    }
		    responsePercent.setPercentageBreakup(percentBreakup);
		 
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return responsePercent;
	
	}

}
