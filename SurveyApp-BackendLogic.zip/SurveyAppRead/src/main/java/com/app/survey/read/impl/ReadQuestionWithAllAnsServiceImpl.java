package com.app.survey.read.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.app.survey.read.connection.ConnectionObject;
import com.app.survey.read.model.Question;
import com.app.survey.read.service.ReadQuestionWithAllAnsService;

@Service
public class ReadQuestionWithAllAnsServiceImpl implements ReadQuestionWithAllAnsService {

	public Question getQuestionWithAnswers(String question) {
		Connection conn = null;
		List<String> listQuestion = null;
		Question ques = null;
		try {
		conn = ConnectionObject.getConnection();
		listQuestion = new ArrayList<String>();
		Statement stmt = null;
		stmt = conn.createStatement();
		String sql = "select answer from t_survey_qa where question='"+question+"'";
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()) {
			String answer = rs.getString("answer");
			listQuestion.add(answer);
		}
		
		ques = new Question();
		ques.setQuestion(question);
		ques.setAnswerOptions(listQuestion);
		
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(conn!=null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return ques;
	
	
	}

}
