package com.app.survey.read.model;

import java.util.List;

public class Question {

	private String question;
	private List<String> answerOptions;
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<String> getAnswerOptions() {
		return answerOptions;
	}
	public void setAnswerOptions(List<String> answerOptions) {
		this.answerOptions = answerOptions;
	}
	
}
