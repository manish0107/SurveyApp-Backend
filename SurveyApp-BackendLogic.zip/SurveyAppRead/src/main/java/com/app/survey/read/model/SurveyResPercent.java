package com.app.survey.read.model;

import java.util.Map;

public class SurveyResPercent {

	private int totalSurveyDone;
	private Map<String, Integer> percentageBreakup;
	
	public int getTotalSurveyDone() {
		return totalSurveyDone;
	}
	public void setTotalSurveyDone(int totalSurveyDone) {
		this.totalSurveyDone = totalSurveyDone;
	}
	public Map<String, Integer> getPercentageBreakup() {
		return percentageBreakup;
	}
	public void setPercentageBreakup(Map<String, Integer> percentageBreakup) {
		this.percentageBreakup = percentageBreakup;
	}
	
	
}
