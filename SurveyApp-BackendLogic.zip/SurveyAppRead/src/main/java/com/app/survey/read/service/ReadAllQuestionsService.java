package com.app.survey.read.service;

import java.util.List;

public interface ReadAllQuestionsService {

	List<String> getAllQuestions();
}
