package com.app.survey.read.service;

import com.app.survey.read.model.SurveyResPercent;

public interface ReadQResPercentageService {

	SurveyResPercent getResponsePrctQues(String question);
}
