package com.app.survey.read.service;

import com.app.survey.read.model.Question;

public interface ReadQuestionWithAllAnsService {

	Question getQuestionWithAnswers(String question);
}
