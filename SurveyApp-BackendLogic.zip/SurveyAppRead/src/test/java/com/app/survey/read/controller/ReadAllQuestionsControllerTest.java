package com.app.survey.read.controller;

import java.util.ArrayList;
import junit.framework.Assert;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import com.app.survey.read.service.ReadAllQuestionsService;

@RunWith(SpringJUnit4ClassRunner.class)
public class ReadAllQuestionsControllerTest {

	@Autowired
	private MockMvc mockMvc;
		
	@Test
	public void testReadAllQuestions() throws Exception{
		ReadAllQuestionsController readAllQuestionsController = Mockito.mock(ReadAllQuestionsController.class);
		List<String> listQuestion = new ArrayList<String>();
		listQuestion.add("What is your name");
		listQuestion.add("What is your age");
		Mockito.when(readAllQuestionsController.getAllQuestions()).thenReturn(listQuestion);
		
		List<String> list = readAllQuestionsController.getAllQuestions();
		Assert.assertNotNull(list);
		
		
	}
}
