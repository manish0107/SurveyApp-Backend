package com.app.survey.read.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.app.survey.read.service.ReadAllQuestionsService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ReadAllQuestionsController.class, secure = false)
public class ReadAllQuestionsControllerTest {
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ReadAllQuestionsService readAllQuestionsService;

	@Test
	public void testGetAllQuestions() throws Exception {

		List<String> listQuestion = new ArrayList<String>();
		listQuestion.add("what is your name");
		listQuestion.add("what is your age");
		Mockito.when(readAllQuestionsService.getAllQuestions()).thenReturn(listQuestion);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getAllQuestions").accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println("result: "+result.getResponse());
		String expected = "[\"what is your name\",\"what is your age\"]";

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

}
