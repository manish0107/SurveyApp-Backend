package com.app.survey.read.controller;

import java.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.app.survey.read.model.Question;
import com.app.survey.read.service.ReadQuestionWithAllAnsService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ReadQuestionWithAllAnsController.class, secure = false)
public class ReadQuestionWithAllAnsTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ReadQuestionWithAllAnsService readQuestionWithAllAnsService;

	@Test
	public void testGetQWithAllA() throws Exception {

		String ans[] = new String[]{"manish","hemant","sebastian"};
		Question quesAns = new Question();
		quesAns.setQuestion("what is your name");
		quesAns.setAnswerOptions(Arrays.asList(ans));
		Mockito.when(readQuestionWithAllAnsService.getQuestionWithAnswers(Mockito.anyString())).thenReturn(quesAns);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getQuestionByName/{question}","what is your name")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println("result: "+result.getResponse());
		String expected = "{\"question\": \"what is your name\",\"answerOptions\": [\"manish\",\"hemant\",\"sebastian\"]}";

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}
}
